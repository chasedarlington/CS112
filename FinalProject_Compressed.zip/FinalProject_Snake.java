package FinalProject;
import java.util.List;
import java.util.LinkedList;

/**
 * A class that stores information about snake (e.g. position, velocity, length, etc.)
 *
 * @author Chase Darlington
 * @version 2019.12.1
 */

public class FinalProject_Snake {
/*----------INSTANCE VARIABLES----------*/	
    private FinalProject_Board board;
    private int length;
    private boolean safe;
    private List<FinalProject_Cell> cells;
    private FinalProject_Cell head;
    private int xVelocity;
    private int yVelocity;

/*----------CONSTRUCTOR METHODS----------*/
    /**
     * @param board board to be copied
     * @param initialCells initial snake cells to be created.
     */
 	public FinalProject_Snake(final FinalProject_Board board, final List<FinalProject_Cell> initialCells) {
        length = initialCells.size();
        cells = new LinkedList<>();
        for (int i=0; i<length; i++)
        	cells.add(initialCells.get(i));
        head = initialCells.get(length-1);
        safe = true;
        this.board = board;
        xVelocity = 0;
        yVelocity = 0;
    }
    
    /**
     * @param other snake object to copy
     */
 	public FinalProject_Snake(final FinalProject_Snake other) {
 		this.board = other.getBoard();
 		this.length = other.getLength();
 		this.safe = other.getSafe();
 		this.cells = other.getCells();
 		this.head = other.getHead();
 		this.xVelocity = other.getXVelocity();
 		this.yVelocity = other.getYVelocity();
 	}

/*----------ACCESSOR METHODS----------*/
	/**
      * @return Game board.
      */ 
    public FinalProject_Board getBoard() {
		return board;
	}

    /**
      * @return Length of snake.
      */ 
	public int getLength() {
		return length;
	}

    /**
      * @return Whether the snake is safe.
      */ 
	public boolean getSafe() {
		return safe || length == 1;
	}

    /**
      * @return List of snake's cells.
      */ 
	public List<FinalProject_Cell> getCells() {
		return cells;
	}

    /**
      * @return Snake head cell.
      */ 
	public FinalProject_Cell getHead() {
		return head;
	}

    /**
      * @return Snake's horizontal (X) velocity.
      */ 
	public int getXVelocity() {
		return xVelocity;
	}

    /**
      * @return Snake's vertical (Y) velocity.
      */ 
	public int getYVelocity() {
		return yVelocity;
	}

/*----------MUTATOR METHODS----------*/
    /**
      * @param board board to set
      */ 
	public void setBoard(final FinalProject_Board board) {
		this.board = board;
	}

    /**
      * @param length snake length
      */ 
	public void setLength(final int length) {
		this.length = length;
	}

    /**
      * @param safe whether the snake is safe
      */ 
	public void setSafe(final boolean safe) {
		this.safe = safe;
	}

    /**
      * @param cells snake cells
      */ 
	public void setCells(final List<FinalProject_Cell> cells) {
		this.cells = cells;
	}

    /**
      * @param head snake head cell
      */     
	public void setHead(final FinalProject_Cell head) {
		this.head = head;
	}

    /**
      * @param xVelocity snake's vertical (x) velocity
      */ 
	public void setXVelocity(final int xVelocity) {
		this.xVelocity = xVelocity;
	}

    /**
      * @param yVelocity snake's vertical (y) velocity
      */ 
	public void setYVelocity(final int yVelocity) {
		this.yVelocity = yVelocity;
	}

/*----------OTHER METHODS----------*/
    /**
     * Checks if the snake is still (i.e. if the game is at the start).
     * @return True if the snake velocity is 0 (vertical and horizontal); true if the snake/game hasn't started yet
     */
    private boolean isStill() {
        return xVelocity == 0 && yVelocity == 0;
    }

    /**
     * Checks for intersection (of the snake with itself) and snake is not out-of-bounds.
     * If either is true, safe is flagged "false"
     * @param cell to check and possibly add.
     */
    private void checkAndAdd(final FinalProject_Cell cell) {
        safe = board.valid(cell) && !cells.contains(cell);
        if (safe) {
        	cells.add(cell);
        	head = cell;
        }
    }

    /**
     * Move snake one square in current direction.
     */
    public void move() {
        if (!isStill()) {
            checkAndAdd(head.move(xVelocity, yVelocity)); //the head goes to new location
            if (safe)
            	cells.remove(0); //the last position is removed
        }
    }

    /**
     * Grow snake one square in current direction.
     */
    public void grow() {
        if (!isStill()) {
            length++;
            checkAndAdd(head.move(xVelocity, yVelocity));
        }
    }

    /**
     * Set vertical velocity to -1 (i.e. x coordinate decreasing).
     */
    public void moveUp() {
        if (yVelocity == 1 && length > 1) return; 
        xVelocity = 0;
        yVelocity = -1;
    }

    /**
     * Set vertical velocity to 1 (i.e. x coordinate increasing).
     */
    public void moveDown() {
        if (yVelocity == -1 && length > 1) return;
        xVelocity = 0;
        yVelocity = 1;
    }

    /**
     * Set horizontal velocity to -1 (i.e. column # decreasing).
     */
    public void moveLeft() {
        if (xVelocity == 1 && length > 1) return;
        xVelocity = -1;
        yVelocity = 0;
    }

    /**
     * Set horizontal velocity to 1 (i.e. column # increasing).
     */
    public void moveRight() {
        if (xVelocity == -1 && length > 1) return;
        xVelocity = 1;
        yVelocity = 0;
    }
}