// /** NOTE: USER NEEDS TO DOWNLOAD JAVAFX 13.0.1 SDK...
//   * AND RUN, WHEN TERMINAL IS OPENED: export PATH_TO_FX="[path-to-downloads]/javafx-sdk-13.0.1/lib"
//   *     e.g. export PATH_TO_FX=/Users/chasedarlington/desktop/final/javafx-sdk-13.0.1/lib
//   * AND RUN, WHEN RUNNING PROGRAMS: 
//   * javac --module-path $PATH_TO_FX --add-modules=javafx.controls [program_name.java]
//   * java --module-path $PATH_TO_FX --add-modules=javafx.controls [program_name]
//   *     e.g. javac --module-path $PATH_TO_FX --add-modules=javafx.controls FinalProject_Main.java
//   *          java --module-path $PATH_TO_FX --add-modules=javafx.controls FinalProject_Main    
//   */

package FinalProject;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.Modality;
import javafx.geometry.Pos;

/**
 * A class to define the main program.
 *
 * @author Chase Darlington
 * @version 2019.12.1
 */

public class FinalProject_Main extends Application {

    private static final int width = 400;
    private static final int height = 400;
    private static int delay;
    private boolean started;
    private FinalProject_Run run;
    private FinalProject_Board board;
    private GraphicsContext context;

    public static void main(String[] args) {
		launch(args);
    }

    /**
      * This method defines the stage/window for the game, and also manages user inputs.
      */
    @Override
    public void start(Stage primaryStage) throws Exception {
    	welcome();
        BorderPane root = new BorderPane();
        Canvas canvas = new Canvas(width, height);
        context = canvas.getGraphicsContext2D();

        canvas.setFocusTraversable(true);
        canvas.setOnKeyPressed(e -> {
            FinalProject_Snake snake = board.getSnake();
            switch (e.getCode()) {
                case UP:
                    if (started) snake.moveUp();
                    else {
                    	started = true;
                    	snake.moveUp();
                    }
                    break;
                case DOWN:
                    if (started) snake.moveDown();
                    else {
                    	started = true;
                    	snake.moveDown();
                    }
                    break;
                case LEFT:
                    if (started) snake.moveLeft(); //assuming the initialized snake is oriented to the Right, only move left if already moved elsewhere (i.e. started)
                    break;
                case RIGHT:
                    if (started) snake.moveRight(); 
                    else {
                    	started = true;
                    	snake.moveRight();
                    }
                    break;
                case SPACE:
                	if (run.getPaused()) {
                		run.setPaused(false);
                		(new Thread(run)).start();
                	}
                	else {
                		run.setPaused(true);
                		FinalProject_Format.formatPauseMessage(context);
                	}
                	break;
                case ENTER:
					if (run.getStopped()) {
						reset();
						(new Thread(run)).start();
					}
            }
        });

        reset();

        root.setCenter(canvas);

        Scene scene = new Scene(root);

        primaryStage.setResizable(false);
        primaryStage.setTitle("Snake Game");
        primaryStage.setOnCloseRequest(e -> {
        	e.consume();
        	closeProgram();
        });
        primaryStage.setScene(scene);
        primaryStage.show();

        (new Thread(run)).start();
    }

    /**
      * This method resets the game when called (the game board, the run, and formats accordingly).
      */
    private void reset() {
        board = new FinalProject_Board(width, height);
        run = new FinalProject_Run(board, context, delay);
        FinalProject_Format.format(board, context);
    }

/*--------------WELCOME WINDOW METHOD--------------*/	
    /**
      * This method displays a "welcome" window that allows a user to set the difficulty of the game.
      */
	private void welcome() {
		//initialize
		Stage stage = new Stage();		
		stage.initModality(Modality.APPLICATION_MODAL);
		stage.setTitle("Welcome to SNAKE");
		stage.setMinWidth(width);
		stage.setMinHeight(height);

		//label
		Label label1 = new Label("Welcome to the Snake Game!");
		label1.setFont(new Font(25));
		Label label2 = new Label("Use your ARROW KEYS to move the snake.");
		label2.setFont(new Font(15));
		Label label3 = new Label("Use the SPACE bar to pause and resume.");
		label3.setFont(new Font(15));


		//button 1
		Button button1 = new Button("Easy");
		button1.setMinWidth(150);
		button1.setOnAction(e -> {
			delay = 80;
			stage.close();
		});

		//button 2
		Button button2 = new Button("Medium");
		button2.setMinWidth(150);
		button2.setOnAction(e -> {
			delay = 40;
			stage.close();
		});

		//button 3
		Button button3 = new Button("Hard");
		button3.setMinWidth(150);
		button3.setOnAction(e -> {
			delay = 20;
			stage.close();
		});


		//layout - children are laid out in vertical column with 20 pixel spacing
		VBox layout = new VBox(10);
		layout.setStyle("-fx-padding: 15 0 15 0;");
		layout.getChildren().addAll(label1,label2,label3,button1,button2,button3);
		layout.setAlignment(Pos.CENTER);

		//window
		Scene scene = new Scene(layout);
		stage.setScene(scene);
		stage.setOnCloseRequest(e -> {
        	e.consume();
        	closeProgram();
        });
		stage.showAndWait();
	}

/*--------------CLOSE PROGRAM METHOD--------------*/		
    /**
      * This method displays a window that asks the user to confirm they want to close the Snake Game window.
      */
	private void closeProgram() {
		//initialize
		Stage alertWindow = new Stage();		
		alertWindow.initModality(Modality.APPLICATION_MODAL);
		alertWindow.setTitle("Please Confirm");
		alertWindow.setMinWidth(300);

		//label
		Label alert = new Label("Sure you want to exit?");

		//button 1
		Button button1 = new Button("Yes");
		button1.setOnAction(e -> {
			alertWindow.close();
			System.exit(0);
		});

		//button 2
		Button button2 = new Button("No");
		button2.setOnAction(e -> alertWindow.close());

		//layout - children are laid out in vertical column with 20 pixel spacing
		VBox layout = new VBox(10);
		layout.setStyle("-fx-padding: 15 0 15 0;");
		layout.getChildren().addAll(alert, button1, button2);
		layout.setAlignment(Pos.CENTER);

		//window
		Scene scene = new Scene(layout);
		alertWindow.setScene(scene);
		alertWindow.showAndWait();
	}
}