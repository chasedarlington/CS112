package FinalProject;

/**
 * A class to store two coordinates (x,y).
 *
 * @author Chase Darlington
 * @version 2019.12.1
 */

public class FinalProject_Cell {
/*----------INSTANCE VARIABLES----------*/
    private int x;    // The X coordinate
    private int y;    // The Y coordinate

/*----------CONSTRUCTOR METHODS----------*/
    /**
     * @param x X coordinate
     * @param y Y coordinate
     */
    public FinalProject_Cell(final int x, final int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * @param other cell to copy
     */
    public FinalProject_Cell(final FinalProject_Cell other) {
        this.x = other.getX();
        this.y = other.getY();
    }

/*----------ACCESSOR METHODS----------*/
    /**
     * @return X coordinate.
     */
    public int getX() {
        return x;
    }

    /**
     * @return Y coordinate.
     */
    public int getY() {
        return y;
    }

/*----------MUTATOR METHODS----------*/
    /**
      * @param x X coordinate
      */
    public void setX(final int x) {
    	this.x = x;
    }

    /**
      * @param y Y coordinate
      */
    public void setY(final int y) {
    	this.y = y;
    }

/*----------OTHER METHODS----------*/
    /**
     * @param dx change in X
     * @param dy change in Y
     * @return A new cell, a result of this move.
     */
    public FinalProject_Cell move(final int dx, final int dy) {
        return new FinalProject_Cell(x + dx, y + dy);
    }

    /**
     * @param other object to compare against
     * @return True if the other Object is an instance of Cell and has the same coordinates.
     */
    public boolean equals(final Object other) {
        if (!(other instanceof FinalProject_Cell)) return false;
        FinalProject_Cell cell = (FinalProject_Cell) other;
        return x == cell.getX() && y == cell.getY();
    }

    /**
     * @return String for the cell coordinates (x,y).
     */
    public String toString() {
        return "(" + x + "," + y + ")";
    }
}