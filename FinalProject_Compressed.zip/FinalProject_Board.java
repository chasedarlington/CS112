package FinalProject;
import java.util.Random;
import java.util.List;
import java.util.LinkedList;

/**
 * A class for the game board. This board will be rendered in Canvas.
 *
 * @author Chase Darlington
 * @version 2019.12.1
 */

public class FinalProject_Board {
/*----------INSTANCE VARIABLES----------*/
    private static int initialSnakeSize = 4;
    private static int cellSize = 10; // length of each square in the grid is 10 pixels
	private int cols; // The number of columns
    private int rows; // The number of rows
    private FinalProject_Snake snake;
    private FinalProject_Cell food;

/*----------CONSTRUCTOR METHODS----------*/
	/**
	  * @param width width of the board
	  * @param height height of the board
	  */
	public FinalProject_Board(final double width, final double height) {
        cols = (int) height / cellSize; 
        rows = (int) width / cellSize; 

        // initialize snake (4 initial cells)
        List<FinalProject_Cell> cells = new LinkedList<>();  //add cells with cells.add(new FinalProject_Cell(x,y))
        for (int i=0; i<initialSnakeSize; i++) {
            cells.add(new FinalProject_Cell(rows/5+i-1,cols/2-1)); //implements integer division to set initial x and y coordinates
        }
        snake = new FinalProject_Snake(this, cells); //FinalProject_Grid as "this" and new cell determined by int division

        // randomly initialize food
        food = getRandomCell();
    }

    /**
      * @param other board to copy
      */
    public FinalProject_Board(final FinalProject_Board other) {
    	this.cellSize = other.getCellSize();
        this.initialSnakeSize = other.getInitialSnakeSize();
    	this.cols = other.getCols();
    	this.rows = other.getRows();
    	this.snake = other.getSnake();
    	this.food = other.getFood();
    }

/*----------ACCESSOR METHODS----------*/
    /**
     * @return Cell size.
     */ 
    public static int getCellSize() {
    	return cellSize;
    }

    /**
     * @return Initial snake size.
     */ 
    public static int getInitialSnakeSize() {
        return initialSnakeSize;
    }

    /**
     * @return Number of columns.
     */ 
    public int getCols() {
        return cols;
    }

    /**
     * @return Number of rows.
     */ 
    public int getRows() {
        return rows;
    }

    /**
     * @return Width of board (in pixels)
     */ 
    public double getWidth() {
        return rows * cellSize;
    }

    /**
     * @return Height of board (in pixels)
     */ 
    public double getHeight() {
        return cols * cellSize;
    }

    /**
     * @return Snake.
     */ 
    public FinalProject_Snake getSnake() {
        return snake;
    }

    /**
     * @return Food cell.
     */ 
    public FinalProject_Cell getFood() {
        return food;
    }

/*----------MUTATOR METHODS----------*/    
    /**
     * @param cellSize pixel width and height of cells
     */ 
    public void setCellSize(int cellSize) {
    	this.cellSize = cellSize;
    }

    /**
     * @param initialSnakeSize initial snake length
     */ 
    public void setInitialSnakeSize(int initialSnakeSize) {
        this.initialSnakeSize = initialSnakeSize;
    }

    /**
     * @param cols number of columns
     */ 
    public void setCols(int cols) {
        this.cols = cols;
    }


    /**
     * @param rows number of rows
     */ 
    public void getRows(int rows) {
        this.rows = rows;
    }


    /**
     * @param snake snake
     */ 
    public void setSnake(FinalProject_Snake snake) {
        this.snake = snake;
    }

    /**
     * @param food food cell
     */ 
    public void getFood(FinalProject_Cell food) {
        this.food = food;
    }


/*----------OTHER METHODS----------*/
    /**
     * @param cell a snake cell
     * @return Whether the cell is in the boundaries of the board.
     */ 
    public boolean valid(FinalProject_Cell cell) {
		int x = cell.getX(); 
        int y = cell.getY();
        if (x >= rows || x < 0 || y >= cols || y < 0)
        	return false;
        else 
        	return true;
    }

    /**
     * @return Random food cell.
     */ 
    private FinalProject_Cell getRandomCell() {
        Random random = new Random();
        FinalProject_Cell cell;
        do {
            cell = new FinalProject_Cell(random.nextInt(rows), random.nextInt(cols)); //random cell within rows and cols parameters
        } while (cell.equals(snake.getHead())); //continue while random cell is the snake head
        return cell;
    }

    /**
     * This method is called in every cycle of execution.
     */
    public void update() {
        if (food.equals(snake.getHead())) {
            snake.grow();
            food = getRandomCell();
        } else {
            snake.move();
        }
    }

}