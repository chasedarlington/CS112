// /** NOTE: USER NEEDS TO DOWNLOAD JAVAFX 13.0.1 SDK...
//   * AND RUN, WHEN TERMINAL IS OPENED: export PATH_TO_FX="[path-to-downloads]/javafx-sdk-13.0.1/lib"
//   *     e.g. export PATH_TO_FX=/Users/chasedarlington/desktop/final/javafx-sdk-13.0.1/lib
//   * AND RUN, WHEN RUNNING PROGRAMS: 
//   * javac --module-path $PATH_TO_FX --add-modules=javafx.controls [program_name.java]
//   * java --module-path $PATH_TO_FX --add-modules=javafx.controls [program_name]
//   *     e.g. javac --module-path $PATH_TO_FX --add-modules=javafx.controls FinalProject_Run.java
//   *          java --module-path $PATH_TO_FX --add-modules=javafx.controls FinalProject_Run   
//   */

package FinalProject;
import javafx.scene.canvas.GraphicsContext;

/**
 * A class to define how the main program runs (frame rate or delay, pausing, user inputs (keys), etc.)
 *
 * @author Chase Darlington
 * @version 2019.12.1
 */

public class FinalProject_Run implements Runnable {
/*----------INSTANCE VARIABLES----------*/  
    private FinalProject_Board board;
    private GraphicsContext context;
    private int delay; //indicates the delay 
    private boolean paused, stopped, keyPressed;

/*----------CONSTRUCTOR METHODS----------*/  
    /**
     * @param board game board
     * @param context graphics context for the game
     * @param delay user-specified delay (set with difficulty) for how often the snake moves (millisecond interval for frequency of updates)
     */ 
    public FinalProject_Run(final FinalProject_Board board, final GraphicsContext context, final int delay) {
        this.board = board;
        this.context = context;
        this.delay = delay;
        paused = false;
        stopped = false;
        keyPressed = false;
    }

    /**
      * @param other runnable to copy
      */
    public FinalProject_Run(FinalProject_Run other) {
        this.board = other.getBoard();
        this.context = other.getContext();
        this.delay = other.getdelay();
        this.paused = other.getPaused();
        this.stopped = other.getStopped();
        this.keyPressed = other.getKeyPressed();
    }

/*----------ACCESSOR METHODS----------*/  
    /**
      * @return Game board.
      */
    public FinalProject_Board getBoard() {
        return board;
    }

    /**
      * @return Graphics context for the game.
      */
    public GraphicsContext getContext() {
        return context;
    }

    /**
      * @return User-specified delay (set with difficulty) for how often the snake moves (millisecond interval for frequency of updates).
      */
    public int getdelay() {
        return delay; 
    }

    /**
      * @return Whether the game is paused.
      */
    public boolean getPaused() { 
        return paused;
    }

    /**
      * @return Whether the game is stopped (i.e. game over).
      */
    public boolean getStopped() { 
        return stopped;
    }

    /**
      * @return Whether a key is pressed.
      */
    public boolean getKeyPressed() {
        return keyPressed;
    }

/*----------MUTATOR METHODS----------*/  
    /**
      * @param board game board
      */
    public void setBoard(FinalProject_Board board) {
        this.board = board;
    }

    /**
      * @param context Graphics context for the game
      */
    public void setContext(GraphicsContext context) {
        this.context = context;
    }

    /**
      * @param delay delay for how often the snake moves (millisecond interval for frequency of updates)
      */
    public void setdelay(int delay) {
        this.delay = delay;
    }

    /**
      * @param paused whether the game is paused
      */
    public void setPaused(boolean paused) { 
        this.paused = paused;
    }

    /**
      * @param stopped whether the game is stopped
      */
    public void setStopped(boolean stopped) { 
        this.stopped = stopped;
    }
    
    /**
      * @param keyPressed whether a key is pressed
      */
    public void setKeyPressed(boolean keyPressed) {
        this.keyPressed = keyPressed;
    }

/*----------OTHER METHODS----------*/  
    /**
      * This method overrides the run() method in runnable and articulates how the game runs.
      * Updates the board.
      * Formats the board and context.
      * Delays snake movement.
      */
    @Override
    public void run() {
        int count = 0;
        while (!paused && !stopped) {
            // Time the update and format calls
            float time = System.currentTimeMillis();

            board.update(); //continue moving the snake
            FinalProject_Format.format(board,context);

            if (!board.getSnake().getSafe()) {
                setStopped(true);
                FinalProject_Format.formatResetMessage(context);
                break;
            }

            time = System.currentTimeMillis() - time;

            // Adjust the timing correctly
            if (time < delay) {
                try {
                    Thread.sleep((long)delay);
                } catch (InterruptedException ignore) {
                }
            }
        }
    }
}