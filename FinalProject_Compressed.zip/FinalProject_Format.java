// /** NOTE: USER NEEDS TO DOWNLOAD JAVAFX 13.0.1 SDK...
//   * AND RUN, WHEN TERMINAL IS OPENED: export PATH_TO_FX="[path-to-downloads]/javafx-sdk-13.0.1/lib"
//   *     e.g. export PATH_TO_FX=/Users/chasedarlington/desktop/final/javafx-sdk-13.0.1/lib
//   * AND RUN, WHEN RUNNING PROGRAMS: 
//   * javac --module-path $PATH_TO_FX --add-modules=javafx.controls [program_name.java]
//   * java --module-path $PATH_TO_FX --add-modules=javafx.controls [program_name]
//   *     e.g. javac --module-path $PATH_TO_FX --add-modules=javafx.controls FinalProject_Format.java
//   *          java --module-path $PATH_TO_FX --add-modules=javafx.controls FinalProject_Format    
//   */

package FinalProject;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * A class for formatting each cell in the GraphicsContext
 * 
 * @author Chase Darlington
 * @version 2019.12.1
 */

public class FinalProject_Format {
/*----------INSTANCE VARIABLES----------*/      
    public static final Color boardColor = new Color(0.1, 0.1, 0.1, 1);
    public static final Color snakeLiveColor = Color.DARKSEAGREEN;
    public static final Color snakeDeadColor = Color.RED;
    public static final Color foodColor = Color.GOLD;
    private static int width, height;

/*----------OTHER METHODS----------*/  
    /**
     * This method formats the context, and ultimately stage, of the game.
     * @param board game board
     * @param context graphics context for the game
     */ 
    public static void format(FinalProject_Board board, GraphicsContext context) {
        context.setFill(boardColor);
        context.fillRect(0, 0, board.getWidth(), board.getHeight());

        context.setFill(foodColor);
        formatCell(board.getFood(), context);

        FinalProject_Snake snake = board.getSnake();
        context.setFill(snakeLiveColor);
        snake.getCells().forEach(cell -> formatCell(cell, context));
        if (!snake.getSafe()) {
            context.setFill(snakeDeadColor);
            formatCell(snake.getHead(), context);
        }

        // The score
        context.setFill(Color.WHITE);
        context.fillText("Score : " + (1 * snake.getCells().size()-FinalProject_Board.getInitialSnakeSize()), 10, board.getHeight()-10);
    }

    /**
     * This method formats an individual cell.
     * @param cell board cell
     * @param context graphics context for the game
     */ 
    private static void formatCell(FinalProject_Cell cell, GraphicsContext context) {
        int cellSize = FinalProject_Board.getCellSize();
        context.fillRect(cell.getX() * cellSize, cell.getY() * cellSize, cellSize, cellSize);
    }

    /**
     * This method formats the pause message (triggered when the user pauses)
     * @param context graphics context for the game
     */ 
    public static void formatPauseMessage(GraphicsContext context) {
        context.setFill(Color.WHITE);
        context.fillText("Hit SPACE to resume.", 130, 200);
    }

    /**
     * This method formats the reset message (triggered when the game is stopped and the user resets)
     * @param context graphics context for the game
     */ 
    public static void formatResetMessage(GraphicsContext context) {
        context.setFill(Color.WHITE);
        context.fillText("Hit RETURN to reset.", 130, 200);
    }
}